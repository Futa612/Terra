<?php
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    .alert {
    padding: 20px;
    background-color: #f44336;
    color: white;
    opacity: 1;
    transition: opacity 0.6s;
    margin-bottom: 15px;
    }

    .alert.success {background-color: #04AA6D;}
    .alert.info {background-color: #2196F3;}
    .alert.warning {background-color: #ff9800;}

    .closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
    }

    .closebtn:hover {
    color: black;
    }
    </style>
</head>
<body>
    <h2>Trạng thái:</h2>
    <div class="alert warning">
        <span class="closebtn">&times;</span>  
        <strong>Sai địa chỉ mail hoặc mật khẩu!</strong>              
    </div>
    <p>Về dăng nhập sau 5s...</p>
    <script>
        var close = document.getElementsByClassName("closebtn");
        var i;

        for (i = 0; i < close.length; i++) {
            close[i].onclick = function(){
                var div = this.parentElement;
                div.style.opacity = "0";
                setTimeout(function(){ div.style.display = "none"; }, 600);
            }
        }   
    </script>                  

</body>
</html>
<?php
    // sleep(3);
    // header("location: index.php");
    // header( "Refresh:5; url=http://localhost/smartroom/index.php", true, 303);
    header( "Refresh:5; index.php", true, 303);
?>
