 <?php
//Cau hinh data base
define('HOSTNAME', "localhost");
define('USERNAME', "rpejkmqn_futa");
define('PASSWORD', "Nguyenphudath2o");
define('DATABASE', "rpejkmqn_terra");

// define('HOSTNAME', "localhost");
// define('USERNAME', "root");
// define('PASSWORD', "");
// define('DATABASE', "rui_esp");
?>
